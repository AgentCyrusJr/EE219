# readme file before compiling

While compiling, make sure to include the dataset file under the same directory as the .py files
there should be two code packs responsible for each part of the project 1 respectively. 

Before packaging, we already make sure every file is compilable, so if there is something wrong with the codes, please contact pengcong@ucla.edu