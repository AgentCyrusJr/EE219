rm -r 3_1/
rm -r 3_2/
mkdir 3_1
mkdir 3_2

python 3_1_#gohawks.py
python 3_1_#gopatriots.py
python 3_1_#patriots.py
python 3_1_#sb49.py

python 3_1_#nfl.py
python 3_1_#superbowl.py
